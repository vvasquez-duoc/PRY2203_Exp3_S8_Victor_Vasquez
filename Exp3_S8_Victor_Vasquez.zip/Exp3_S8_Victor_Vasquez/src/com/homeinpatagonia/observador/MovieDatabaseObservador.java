package com.homeinpatagonia.observador;

public interface MovieDatabaseObservador {
    void onDatabaseChanged();
}
